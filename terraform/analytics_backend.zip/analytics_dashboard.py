import json
import os
import urllib.error
import urllib.request
from decimal import Decimal

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from strategy import StrategyEvaluator


TABLE_NAME = os.environ.get("DYNAMO_TABLE", "analytics_dashboard_dynamo")
OPENAI_SECRET_ARN = os.environ.get("OPENAI_API_KEY_SECRET_ARN", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"

dynamodb = boto3.resource("dynamodb")
secretsmanager = boto3.client("secretsmanager")
table = dynamodb.Table(TABLE_NAME)


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, ensure_ascii=False),
    }


def _parse_event(event):
    if isinstance(event, dict) and "body" in event:
        body = event.get("body") or {}
        if isinstance(body, str):
            return json.loads(body) if body else {}
        return body
    return event or {}


def _clean_text(value): # serve per pulire la formattazione di acc
    if not isinstance(value, str):
        return value
    return value.replace("\u0000", "").strip()


def _to_dynamo_value(value): # convertiamo tutti i float in decimal per dynamo
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {key: _to_dynamo_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_to_dynamo_value(item) for item in value]
    return value


def _to_json_value(value): # qui facciamo il cotnrario, prendiamo la risposta decimale la convertiamo in json
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, dict):
        return {key: _to_json_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_to_json_value(item) for item in value]
    return value


def _lap_number(lap):
    try:
        return int(lap.get("lap_number", -1))
    except (TypeError, ValueError):
        return -1


def _latest_lap_sequence(laps):
    sequence = []
    for lap in laps:
        sequence.append(lap)
        if _lap_number(lap) <= 1:
            break
    return sequence


def get_recent_laps(driver, track=None, session_id=None, limit=5, search_limit=30):
    if not driver:
        return []

    laps = []
    start_key = None

    try:
        while True:
            query_args = {
                "KeyConditionExpression": Key("driver").eq(driver),
                "ScanIndexForward": False,
                "Limit": search_limit,
            }
            if start_key:
                query_args["ExclusiveStartKey"] = start_key

            response = table.query(**query_args)

            page_laps = response.get("Items", [])
            if session_id:
                page_laps = [lap for lap in page_laps if lap.get("session_id") == session_id]
            if track:
                page_laps = [lap for lap in page_laps if lap.get("track") == track]

            laps.extend(page_laps)
            if session_id and any(_lap_number(lap) <= 1 for lap in laps):
                break
            if not session_id and limit is not None and len(laps) >= limit:
                break

            start_key = response.get("LastEvaluatedKey")
            if not start_key:
                break
    except ClientError as error:
        print("Storico giri non disponibile:", error.response["Error"]["Message"])
        return []

    if session_id:
        laps = _latest_lap_sequence(laps)

    selected_laps = laps if limit is None else laps[:limit]
    return list(reversed(selected_laps))


def enrich_lap_with_strategy(lap):
    session_id = lap.get("session_id")
    recent_laps = get_recent_laps(
        lap.get("driver"),
        lap.get("track"),
        session_id,
        limit=None if session_id else 4,
        search_limit=120,
    )
    strategy_window = max(len(recent_laps) + 1, 5) if session_id else 5
    strategy = StrategyEvaluator(last_laps=strategy_window)
    strategy.load_history(recent_laps)
    lap.update(strategy.add_lap(lap))
    return lap


def save_lap(payload):
    lap = dict(payload)
    lap["driver"] = _clean_text(lap.get("driver"))
    lap["track"] = _clean_text(lap.get("track"))
    lap = enrich_lap_with_strategy(lap)

    try:
        table.put_item(Item=_to_dynamo_value(lap))
    except ClientError as error:
        print("Errore scrittura DynamoDB:", error.response["Error"]["Message"])
        return _response(500, {"message": "Errore durante il salvataggio del giro."})

    print(
        "Giro salvato:",
        json.dumps({
            "driver": lap.get("driver"),
            "track": lap.get("track"),
            "lap_number": lap.get("lap_number"),
            "lap_time_ms": lap.get("lap_time_ms"),
        }),
    )
    return _response(200, {"message": "Giro salvato correttamente.", "lap": _to_json_value(lap)})


def read_openai_api_key():
    if not OPENAI_SECRET_ARN:
        raise RuntimeError("OPENAI_API_KEY_SECRET_ARN non configurato sulla Lambda.")

    secret = secretsmanager.get_secret_value(SecretId=OPENAI_SECRET_ARN)
    secret_string = secret.get("SecretString", "")

    try:
        secret_json = json.loads(secret_string)
        api_key = secret_json.get("OPENAI_API_KEY") or secret_json.get("api_key")
    except json.JSONDecodeError:
        api_key = secret_string

    if not api_key:
        raise RuntimeError("Secret OpenAI vuoto o in formato non valido.")

    return api_key.strip()


def compact_lap(lap):
    lap = _to_json_value(lap)
    return {
        "lap_number": lap.get("lap_number"),
        "session_id": lap.get("session_id"),
        "session_type": lap.get("session_type"),
        "lap_time_ms": lap.get("lap_time_ms"),
        "is_valid_lap": lap.get("is_valid_lap"),
        "sector_times_ms": lap.get("sector_times_ms"),
        "fuel_left_L": lap.get("fuel_left_L"),
        "fuel_consumed_L": lap.get("fuel_consumed_L"),
        "fuel_laps_possible": lap.get("fuel_laps_possible"),
        "avg_tyre_core_C": lap.get("avg_tyre_core_C"),
        "avg_brake_temp_C": lap.get("avg_brake_temp_C"),
        "slip_events_by_sector": lap.get("slip_events_by_sector"),
        "max_slip_by_sector": lap.get("max_slip_by_sector"),
        "tyre_age_laps": lap.get("tyre_age_laps"),
        "track_grip_status": lap.get("track_grip_status"),
        "strategy_push_level": lap.get("strategy_push_level"),
        "strategy_warning": lap.get("strategy_warning"),
        "strategy_advice": lap.get("strategy_advice"),
    }


def extract_openai_text(response_body):
    if response_body.get("output_text"):
        return response_body["output_text"]

    texts = []
    for item in response_body.get("output", []):
        for content in item.get("content", []):
            text = content.get("text")
            if text:
                texts.append(text)
    return "\n".join(texts).strip()


def ask_openai_engineer(driver, track, question, laps):
    api_key = read_openai_api_key()
    context = {
        "driver": driver,
        "track": track,
        "engineer_question": question,
        "recent_laps": [compact_lap(lap) for lap in laps],
    }

    request_body = {
        "model": OPENAI_MODEL,
        "input": [
            {
                "role": "system",
                "content": (
                    "Sei un assistente per un ingegnere di pista in Assetto Corsa "
                    "Competizione. Usa solo i dati forniti, non inventare telemetria "
                    "mancante, distingui fatti osservati e ipotesi, e rispondi in italiano."
                ),
            },
            {
                "role": "user",
                "content": json.dumps(context, ensure_ascii=False),
            },
        ],
        "max_output_tokens": 700,
    }

    request = urllib.request.Request(
        OPENAI_RESPONSES_URL,
        data=json.dumps(request_body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            response_body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8")
        raise RuntimeError(f"OpenAI API error {error.code}: {detail[:500]}") from error
    except urllib.error.URLError as error:
        raise RuntimeError(f"OpenAI API non raggiungibile: {error.reason}") from error

    text = extract_openai_text(response_body)
    if not text:
        raise RuntimeError("OpenAI non ha restituito testo utile.")
    return text


def handle_ai_insight(payload):
    driver = _clean_text(payload.get("driver"))
    track = _clean_text(payload.get("track"))
    session_id = payload.get("session_id")
    question = payload.get(
        "question",
        "Analizza gli ultimi giri e indica priorita', rischi e azione consigliata.",
    )
    limit = int(payload.get("limit", 80))

    if not driver:
        return _response(400, {"message": "Parametro driver obbligatorio."})

    laps = get_recent_laps(
        driver,
        track,
        session_id,
        limit=limit,
        search_limit=max(limit * 3, 120),
    )
    if not laps:
        return _response(404, {"message": "Nessun giro trovato per la richiesta AI."})

    try:
        insight = ask_openai_engineer(driver, track, question, laps)
    except (RuntimeError, ClientError) as error:
        print("Errore AI insight:", str(error))
        return _response(502, {"message": "Analisi AI non disponibile.", "detail": str(error)})

    return _response(200, {
        "driver": driver,
        "track": track,
        "session_id": session_id,
        "model": OPENAI_MODEL,
        "laps_analyzed": len(laps),
        "question": question,
        "ai_engineer_insight": insight,
    })


def handler(event, context):
    payload = _parse_event(event)

    if payload.get("action") == "ai_insight":
        return handle_ai_insight(payload)

    return save_lap(payload)
